<div class="w-full sm:w-8/12 mx-auto p-6 sm:p-8 bg-white rounded-lg shadow-lg mb-4 mt-4 h-fit">
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">Appointment Form</h2>

    <div class="mb-6">
        <h3 class="text-xl font-medium text-gray-700 mb-4">Schedule Your Appointment</h3>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">


            <div>
                <label class="block text-sm font-medium text-gray-700">Name</label>
                <input type="text" wire:model="name" class="w-full mt-1 p-2 border border-gray-300 rounded-md" placeholder="Name">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div>
                <label class="block text-sm font-medium text-gray-700">Phone Number</label>
                <input type="text" wire:model="phone_number" class="w-full mt-1 p-2 border border-gray-300 rounded-md" placeholder="Phone Number">
                <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div class="sm:col-span-2">
                <label class="block text-sm font-medium text-gray-700">Address</label>
                <input type="text" wire:model="address" class="w-full mt-1 p-2 border border-gray-300 rounded-md" placeholder="Address">
                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div>
                <label class="block text-sm font-medium text-gray-700">Time of Schedule</label>
                <input type="time" wire:model="time_schedule" class="w-full mt-1 p-2 border border-gray-300 rounded-md">
                <?php $__errorArgs = ['time_schedule'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div>
                <label class="block text-sm font-medium text-gray-700">Date of Schedule</label>
                <input type="date" wire:model="date_schedule" class="w-full mt-1 p-2 border border-gray-300 rounded-md">
                <?php $__errorArgs = ['date_schedule'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div class="sm:col-span-2">
                <label class="block text-sm font-medium text-gray-700">Reason for Appointment</label>
                <textarea wire:model="reason" rows="4" class="w-full mt-1 p-2 border border-gray-300 rounded-md" placeholder="Describe the reason for your appointment"></textarea>
                <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div class="sm:col-span-2">
                <label class="block text-sm font-medium text-gray-700">Mode of Payment</label>
                <select wire:model="mop" class="w-full mt-1 p-2 border border-gray-300 rounded-md">
                    <option value="Walk-in">Walk-in</option>
                    <option value="Gcash">Gcash</option>
                    <option value="Credit Card">Credit Card</option>
                </select>
                <?php $__errorArgs = ['mop'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div class="sm:col-span-2" x-data="{ show: false }" x-init="$watch('$wire.mop', value => show = ['Gcash', 'Credit Card'].includes(value))">
                <label class="block text-sm font-medium text-gray-700">Receipt (Optional for Gcash/Credit Card)</label>
                <input type="file" wire:model="receipt" class="w-full mt-1 p-2 border border-gray-300 rounded-md" x-show="show">
                <?php $__errorArgs = ['receipt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

    <div class="flex justify-end mt-6">
        <button wire:click="submit" class="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Submit</button>
    </div>

    <?php if(session()->has('message')): ?>
        <div class="mt-4 text-green-500">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
</div><?php /**PATH D:\laravel\dentalbliss\resources\views\livewire\user\appointment.blade.php ENDPATH**/ ?>