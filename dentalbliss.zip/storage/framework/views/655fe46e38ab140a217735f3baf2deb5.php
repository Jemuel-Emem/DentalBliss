<div class="p-8 max-w-7xl mx-auto bg-white rounded-lg shadow-xl">
    <h2 class="text-3xl font-semibold text-gray-800 mb-6 text-center">Your Appointments</h2>

    <?php if($appointments->isEmpty()): ?>
        <div class="bg-red-50 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-md">
            <p class="font-medium text-lg">No appointments found</p>
        </div>
    <?php else: ?>
        <table class="w-full bg-gray-50 rounded-lg shadow-sm">
            <thead>
                <tr>
                    <th class="py-3 px-6 text-left text-gray-700 font-semibold border-b">Name</th>
                    <th class="py-3 px-6 text-left text-gray-700 font-semibold border-b">Reason</th>
                    <th class="py-3 px-6 text-left text-gray-700 font-semibold border-b">Scheduled Date</th>
                    <th class="py-3 px-6 text-left text-gray-700 font-semibold border-b">Status</th>
                    <th class="py-3 px-6 text-left text-gray-700 font-semibold border-b">Prescriptions</th> <!-- Added column for Prescriptions -->
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="bg-white border-b hover:bg-gray-100">
                        <td class="py-4 px-6 text-gray-800"><?php echo e($appointment->name); ?></td>
                        <td class="py-4 px-6 text-gray-800"><?php echo e($appointment->reason); ?></td>
                        <td class="py-4 px-6 text-gray-800"><?php echo e($appointment->date_schedule->format('Y-m-d')); ?></td>
                        <td class="py-4 px-6">
                            <span class="px-3 py-1 inline-block text-sm font-medium rounded-full
                            <?php if($appointment->status == 'Approved'): ?> bg-green-100 text-green-600
                            <?php elseif($appointment->status == 'Declined'): ?> bg-red-100 text-red-600
                            <?php else: ?> bg-yellow-100 text-yellow-600 <?php endif; ?>">
                                <?php echo e($appointment->status); ?>

                            </span>
                        </td>
                        <td class="py-4 px-6">

                            <?php if($appointment->prescriptions->isEmpty()): ?>
                                <span>No prescriptions available</span>
                            <?php else: ?>
                                <ul>
                                    <?php $__currentLoopData = $appointment->prescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prescription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="mb-2">
                                            <strong>Treatment:</strong> <?php echo e($prescription->treatment); ?><br>
                                            <strong>Medicine:</strong> <?php echo e($prescription->medicine); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div><?php /**PATH D:\laravel\dentalbliss\resources\views\livewire\user\status.blade.php ENDPATH**/ ?>