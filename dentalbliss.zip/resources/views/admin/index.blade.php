<x-admin-layout>
    <div>

        <div class=" ">
            <livewire:admin.index/>
        </div>

    </div>
</x-admin-layout>
