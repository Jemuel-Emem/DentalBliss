<x-admin-layout>
    <div>

        <div class=" ">
            <livewire:admin.prescription/>
        </div>

    </div>
</x-admin-layout>
