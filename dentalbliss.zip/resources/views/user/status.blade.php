<x-user-layout>
    <div>

        <div class="">
            <livewire:user.status/>
        </div>

    </div>
</x-user-layout>
