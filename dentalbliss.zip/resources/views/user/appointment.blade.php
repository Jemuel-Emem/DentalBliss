<x-user-layout>
    <div>

        <div class=" h-screen flex justify-center w-full">
            <livewire:user.appointment/>
        </div>

    </div>
</x-user-layout>
